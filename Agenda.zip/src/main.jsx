import React from 'react'
import ReactDOM from 'react-dom/client'
import AgendaJesusTalentLand from './AgendaJesusTalentLand'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <AgendaJesusTalentLand />
  </React.StrictMode>,
)
